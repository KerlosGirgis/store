export default function ProductDetails() {
  return (
    <></>
  )
}